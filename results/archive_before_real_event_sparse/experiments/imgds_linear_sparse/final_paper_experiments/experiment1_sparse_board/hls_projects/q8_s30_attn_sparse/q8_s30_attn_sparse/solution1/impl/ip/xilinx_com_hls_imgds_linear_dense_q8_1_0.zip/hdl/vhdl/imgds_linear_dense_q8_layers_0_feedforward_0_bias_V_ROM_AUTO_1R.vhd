-- ==============================================================
-- Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
-- Version: 2022.2
-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- ==============================================================
library ieee; 
use ieee.std_logic_1164.all; 
use ieee.std_logic_unsigned.all;

entity imgds_linear_dense_q8_layers_0_feedforward_0_bias_V_ROM_AUTO_1R is 
    generic(
             DataWidth     : integer := 4; 
             AddressWidth     : integer := 5; 
             AddressRange    : integer := 32
    ); 
    port (
 
          address0        : in std_logic_vector(AddressWidth-1 downto 0); 
          ce0             : in std_logic; 
          q0              : out std_logic_vector(DataWidth-1 downto 0);

          reset               : in std_logic;
          clk                 : in std_logic
    ); 
end entity; 


architecture rtl of imgds_linear_dense_q8_layers_0_feedforward_0_bias_V_ROM_AUTO_1R is 
 
signal address0_tmp : std_logic_vector(AddressWidth-1 downto 0); 

type mem_array is array (0 to AddressRange-1) of std_logic_vector (DataWidth-1 downto 0); 

signal mem0 : mem_array := (
    0 => "0001", 1 => "0000", 2 => "1100", 3 => "0001", 
    4 => "1011", 5 => "0010", 6 => "0000", 7 => "0001", 
    8 => "0011", 9 => "0000", 10 => "0000", 11 => "1101", 
    12 => "1101", 13 => "0010", 14 => "0011", 15 => "1110", 
    16 => "0001", 17 => "1111", 18 => "0011", 19 => "1110", 
    20 => "0011", 21 => "0010", 22 => "0010", 23 => "0010", 
    24 => "0001", 25 => "0001", 26 => "1101", 27 => "1111", 
    28 => "1111", 29 => "0001", 30 => "1110", 31 => "0011");



begin 

 
memory_access_guard_0: process (address0) 
begin
      address0_tmp <= address0;
--synthesis translate_off
      if (CONV_INTEGER(address0) > AddressRange-1) then
           address0_tmp <= (others => '0');
      else 
           address0_tmp <= address0;
      end if;
--synthesis translate_on
end process;

p_rom_access: process (clk)  
begin 
    if (clk'event and clk = '1') then
 
        if (ce0 = '1') then  
            q0 <= mem0(CONV_INTEGER(address0_tmp)); 
        end if;

end if;
end process;

end rtl;

