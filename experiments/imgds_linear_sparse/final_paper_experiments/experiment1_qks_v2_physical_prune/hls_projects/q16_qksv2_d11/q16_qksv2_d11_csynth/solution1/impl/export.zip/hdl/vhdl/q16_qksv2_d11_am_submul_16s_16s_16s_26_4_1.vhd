-- ==============================================================
-- Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
-- Tool Version Limit: 2019.12
-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- ==============================================================
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.numeric_std.all;

entity q16_qksv2_d11_am_submul_16s_16s_16s_26_4_1_DSP48_8 is
port (
    clk: in  std_logic;
    rst: in  std_logic;
    ce:  in  std_logic;
    in0:  in  std_logic_vector(16 - 1 downto 0);
    in1:  in  std_logic_vector(16 - 1 downto 0);
    in2:  in  std_logic_vector(16 - 1 downto 0);
    dout: out std_logic_vector(26 - 1 downto 0));

end entity;

architecture behav of q16_qksv2_d11_am_submul_16s_16s_16s_26_4_1_DSP48_8 is
    signal b       : signed(18-1 downto 0);
    signal a       : signed(25-1 downto 0);
    signal d       : signed(25-1 downto 0);
    signal m       : signed(43-1 downto 0);
    signal ad      : signed(25-1 downto 0);
    signal m_reg   : signed(43-1 downto 0);
    signal ad_reg  : signed(25-1 downto 0);
    signal b_reg   : signed(18-1 downto 0);
    signal p_reg   : signed(48-1 downto 0);
begin
a <= signed(resize(signed(in0), 25));
d <= signed(resize(signed(in1), 25));
b <= signed(resize(signed(in2), 18));

ad <= a - d;
m  <= ad_reg * b_reg;

process (clk) begin
    if (clk'event and clk = '1') then
        if (ce = '1') then
            m_reg <= m;
            ad_reg <= ad;
            b_reg  <= b;
            p_reg  <= resize(m_reg, 48);
        end if;
    end if;
end process;

dout <= std_logic_vector(resize(unsigned(p_reg), 26));

end architecture;
Library IEEE;
use IEEE.std_logic_1164.all;

entity q16_qksv2_d11_am_submul_16s_16s_16s_26_4_1 is
    generic (
        ID : INTEGER;
        NUM_STAGE : INTEGER;
        din0_WIDTH : INTEGER;
        din1_WIDTH : INTEGER;
        din2_WIDTH : INTEGER;
        dout_WIDTH : INTEGER);
    port (
        clk : IN STD_LOGIC;
        reset : IN STD_LOGIC;
        ce : IN STD_LOGIC;
        din0 : IN STD_LOGIC_VECTOR(din0_WIDTH - 1 DOWNTO 0);
        din1 : IN STD_LOGIC_VECTOR(din1_WIDTH - 1 DOWNTO 0);
        din2 : IN STD_LOGIC_VECTOR(din2_WIDTH - 1 DOWNTO 0);
        dout : OUT STD_LOGIC_VECTOR(dout_WIDTH - 1 DOWNTO 0));
end entity;

architecture arch of q16_qksv2_d11_am_submul_16s_16s_16s_26_4_1 is
    component q16_qksv2_d11_am_submul_16s_16s_16s_26_4_1_DSP48_8 is
        port (
            clk : IN STD_LOGIC;
            rst : IN STD_LOGIC;
            ce : IN STD_LOGIC;
            in0 : IN STD_LOGIC_VECTOR;
            in1 : IN STD_LOGIC_VECTOR;
            in2 : IN STD_LOGIC_VECTOR;
            dout : OUT STD_LOGIC_VECTOR);
    end component;



begin
    q16_qksv2_d11_am_submul_16s_16s_16s_26_4_1_DSP48_8_U :  component q16_qksv2_d11_am_submul_16s_16s_16s_26_4_1_DSP48_8
    port map (
        clk => clk,
        rst => reset,
        ce => ce,
        in0 => din0,
        in1 => din1,
        in2 => din2,
        dout => dout);

end architecture;


