# ViT4Mal Reference Baselines (from ViT4Mal paper Table 13)

| method   | dataset   | board   | architecture         |   accuracy |   BRAM |   DSP |   LUT |    FF |   power_w |   inference_time_s | notes                 |
|:---------|:----------|:--------|:---------------------|-----------:|-------:|------:|------:|------:|----------:|-------------------:|:----------------------|
| ViT4Mal  | IMG_DS    | PYNQ-Z1 | 4 encoders & 4 heads |      92.16 |     84 |    69 | 16135 | 16364 |      1.89 |               2.82 | dense ViT             |
| ViT4Mal  | IMG_DS    | PYNQ-Z1 | 4 encoders & 2 heads |      93.16 |     92 |    69 | 16200 | 16390 |      1.9  |               2.81 | dense ViT             |
| ViT4Mal  | IMG_DS    | PYNQ-Z1 | 2 encoders & 4 heads |      93.89 |     84 |    69 | 16079 | 16356 |      1.87 |               1.48 | dense ViT recommended |
| ViT4Mal  | IMG_DS    | PYNQ-Z1 | 2 encoders & 2 heads |      93.86 |     92 |    69 | 16219 | 16393 |      1.88 |               1.45 | dense ViT             |
| ViT4Mal  | IMG_DS    | PYNQ-Z1 | 1 encoder & 4 heads  |      92.47 |     84 |    69 | 16029 | 16358 |      1.85 |               0.87 | dense ViT             |
| ViT4Mal  | IMG_DS    | PYNQ-Z1 | 1 encoder & 2 heads  |      92.41 |     92 |    69 | 16545 | 16911 |      1.89 |               0.81 | dense ViT fastest     |

Note: These results are from ViT4Mal with dense ViT attention on PYNQ-Z1.
Our Linear Transformer baseline targets comparable accuracy with lower FPGA resource usage.
